const cleanServerCode = require('./lib/cleanServerCode');

cleanServerCode();