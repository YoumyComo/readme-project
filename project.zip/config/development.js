const Path = require('path');

module.exports = {
  isDev: true,
  isMock: false,
  datadir: Path.join(__dirname, '../data'),
}
