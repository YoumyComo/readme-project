module.exports = {
  isDev: false,
  isMock: false,
};
