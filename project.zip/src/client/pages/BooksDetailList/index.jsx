import * as React from 'react';
import '@client/styles/business.scss';
import BookService from '../../services/book';

export default class BooksDetailList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
        }
    }

    updateRenderBook() {
        // 添加书籍后是否会自动更新？
        const { books } = this.state;
        let trList = [];
        if(books.length) {
            books.map((book) => {
                trList.push(   <tr key={book}>
                            <th>{book}</th>
                            <th>b</th>
                            <th>c</th>
                            <th>d</th>                                            
                        </tr>);
            });
            return trList;
        } else 
            return;

    }

    componentWillReceiveProps() {

    }
    async componentDidMount() {
        const books =  await BookService.getBook();
        this.setState({ books });
    }
    render() {
        const { books } = this.state;
        
        //问题1： 如果除了chapter外还有其他属性该怎么写 ？？？
        if (!books) return null;
        return ( 
                <div> 
                    <table  className="table-wrapper">
                        <thead className="table-header">
                            <tr>
                                <th>书籍</th>
                                <th>日期</th>
                                <th>编辑</th>
                                <th>删除</th>                                            
                            </tr>
                        </thead>
                        <tbody>
                            {this.updateRenderBook()}
                        </tbody>
                    </table>                                                 
                </div>   
    )
    }

}