import * as React from 'react';

export default class BookEdit extends React.Component {
    render() {
        return(
            <div>
                哈哈
            </div>
        )
    }
}