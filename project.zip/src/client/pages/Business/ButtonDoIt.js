import * as React from 'react';
import '@client/styles/business.scss';

// const ButtonGroup = Button.Group;   //按钮组


export default class ButtonDoIt extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

        }
    }
    createBook() {

    }
    deletBook() {

    }
    render() {
        return (   
                <div className="doit">
                    <button type="ghost" onClick={this.createBook.bind(this)} icon="minus" >创建书籍 </button>
                    <button type="ghost" onClick={this.deletBook.bind(this)} icon="plus" >删除书籍 </button>
                </div>
                                  
       )
    }

}