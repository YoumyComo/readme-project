import * as React from 'react';
import {Route} from 'react-router';
import '@client/styles/business.scss';
import ButtonDoIt from './ButtonDoIt';
import BookService from '../../services/book';

import BooksDetailList from '../BooksDetailList';
import BookEdit from '../BookEdit';

export default class Business extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            currentPath: null,
            booksLists: true
        }
    }

    bookList() {
        const { books } = this.state;
        let trList = [];
        if(books.length) {
            books.map((book) => {
                trList.push(   <li key={book}>{book} </li>);
            });
            return trList;
        } else 
            return;

    }

    async componentDidMount() {
            const books =  await BookService.getBook();
            this.setState({ books });
    }
    render() {
        const { books, booksLists} = this.state;
        
        //问题1： 如果除了chapter外还有其他属性该怎么写 ？？？
        if (!books) return null;
        return (
                <section className="business-container">
                    <header className="header">后台管理 </header>
                    <section className="content-container">
                        <aside className="catalog-container">
                            <ul>
                                <li><span>&</span>已添加</li>
                                {this.bookList()}
                            </ul>
                            
                        </aside>
                        <section className="edit-wrapper">
                            <section className="edit-container">
                                <div className="panel"> 
                                    <header >书籍管理 </header>   
                                    <ButtonDoIt/>  
                                </div>   
                                <BooksDetailList />
                                {/* {booksLists  ?  <Route exact path="/bussiness/books-detail-list" component={BooksDetailList}/>
                                    : <Route exact path="/bussiness/book-edit/book" component={BookEdit}/>} */}
                            </section>
                        </section>
                        
                    </section>
                </section>
            
        )
    }

}