import Net from '../lib/Net';
const net = new Net([]);

export default {
    async getBook(spell) {
        const resp = await net.request({
            url: {
                pathname: `/api/books`
            }
        });
        return resp.body;
    }
}