import {route} from './decorator';
import * as Config from 'config';
import {Context} from 'koa';
import {promisify} from 'util';
import * as fs from 'fs';
import * as Path from 'path';

const readdir = promisify(fs.readdir);

export default class WordController {
  @route('get', '/api/words')
  async list(ctx: Context) {
    const filepath = Path.join(Config.get('datadir'), 'words');
    ctx.body = (await readdir(filepath)).map(d =>  Path.basename(d, '.json'));
  }

  @route('post', '/api/words')
  add(_: Context) {

  }

  @route('get', '/api/words/:spell')
  get(ctx: Context) {
    const { spell } = ctx.params;
    ctx.set('Content-Type', 'Application/json');
    const filepath = Path.join(Config.get('datadir'), 'words', `${spell}.json`);
    ctx.body = fs.createReadStream(filepath);
  }

  @route('put', '/api/words')
  edit(_: Context) {

  }

  @route('delete', '/api/words/:id')
  delete(_: Context) {

  }
}
