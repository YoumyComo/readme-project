import {route} from './decorator';
import * as Config from 'config';
import {Context} from 'koa';
import {promisify} from 'util';
import * as fs from 'fs';
import * as Path from 'path';

const readdir = promisify(fs.readdir);

export default class WordController {
  @route('get', '/api/books')
  async list(ctx: Context) {
    const filepath = Path.join(Config.get('datadir'), 'books');
    ctx.body = await readdir(filepath);
  }

  @route('post', '/api/books')
  add(_: Context) {

  }

  @route('get', '/api/books/:chapter')
  get(_: Context) {
  }

  @route('put', '/api/books')
  edit(_: Context) {

  }

  @route('delete', '/api/books/:id')
  delete(_: Context) {

  }
}
