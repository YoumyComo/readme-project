import {route} from './decorator';
import * as Config from 'config';
import {Context} from 'koa';
// import {promisify} from 'util';
import * as fs from 'fs';
import * as Path from 'path';

export default class QRCodeController {
  @route('get', '/api/images/:word')
  async get(ctx: Context) {
    const { word } = ctx.params;

    const filepath = Path.join(Config.get('datadir'), 'images', `${word}.jpg`);
    ctx.set('Content-Type', 'image/jpeg');
    ctx.body = fs.createReadStream(filepath);
  }
}
