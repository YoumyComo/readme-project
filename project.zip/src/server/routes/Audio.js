"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const decorator_1 = require("./decorator");
const Config = require("config");
const fs = require("fs");
const Path = require("path");
const youdao_1 = require("../services/youdao");
const youdao = new youdao_1.default();
const request = require('request');
class AudioController {
    get(ctx) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            const { word } = ctx.params;
            const filepath = Path.join(Config.get('datadir'), 'audios', `${word}.mp3`);
            ctx.set('Content-Type', 'audio/mpeg');
            ctx.body = fs.createReadStream(filepath);
        });
    }
    add(ctx) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            const { word } = ctx.params;
            const translation = yield youdao.translate(word);
            const filepath = Path.join(Config.get('datadir'), 'audios', `${word}.mp3`);
            request(translation.speakUrl).pipe(fs.createWriteStream(filepath));
        });
    }
    edit(_) {
    }
}
tslib_1.__decorate([
    decorator_1.route('get', '/api/audios/:word')
], AudioController.prototype, "get", null);
tslib_1.__decorate([
    decorator_1.route('put', '/api/audios/:word')
], AudioController.prototype, "add", null);
tslib_1.__decorate([
    decorator_1.route('put', '/api/audios')
], AudioController.prototype, "edit", null);
exports.default = AudioController;
//# sourceMappingURL=Audio.js.map