import {route} from './decorator';
import * as Config from 'config';
import {Context} from 'koa';
// import {promisify} from 'util';
import * as fs from 'fs';
import * as Path from 'path';
import Youdao from '../services/youdao';

const youdao = new Youdao();
const request = require('request');

export default class AudioController {
  @route('get', '/api/audios/:word')
  async get(ctx: Context) {
    const { word } = ctx.params;
    const filepath = Path.join(Config.get('datadir'), 'audios', `${word}.mp3`);
    ctx.set('Content-Type', 'audio/mpeg');
    ctx.body = fs.createReadStream(filepath);
  }

  @route('put', '/api/audios/:word')
  async add(ctx: Context) {
   const { word } = ctx.params;
   const translation = await youdao.translate(word);
   const filepath = Path.join(Config.get('datadir'), 'audios', `${word}.mp3`);

   request(translation.speakUrl).pipe(fs.createWriteStream(filepath));
  }

  @route('put', '/api/audios')
  edit(_: Context) {

  }
}
