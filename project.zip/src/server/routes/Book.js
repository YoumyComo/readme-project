"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const decorator_1 = require("./decorator");
const Config = require("config");
const util_1 = require("util");
const fs = require("fs");
const Path = require("path");
const readdir = util_1.promisify(fs.readdir);
class WordController {
    list(ctx) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            const filepath = Path.join(Config.get('datadir'), 'books');
            ctx.body = yield readdir(filepath);
        });
    }
    add(_) {
    }
    get(_) {
    }
    edit(_) {
    }
    delete(_) {
    }
}
tslib_1.__decorate([
    decorator_1.route('get', '/api/books')
], WordController.prototype, "list", null);
tslib_1.__decorate([
    decorator_1.route('post', '/api/books')
], WordController.prototype, "add", null);
tslib_1.__decorate([
    decorator_1.route('get', '/api/books/:chapter')
], WordController.prototype, "get", null);
tslib_1.__decorate([
    decorator_1.route('put', '/api/books')
], WordController.prototype, "edit", null);
tslib_1.__decorate([
    decorator_1.route('delete', '/api/books/:id')
], WordController.prototype, "delete", null);
exports.default = WordController;
//# sourceMappingURL=Book.js.map