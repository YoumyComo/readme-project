"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("tslib");
const decorator_1 = require("./decorator");
const Config = require("config");
const fs = require("fs");
const Path = require("path");
class QRCodeController {
    get(ctx) {
        return tslib_1.__awaiter(this, void 0, void 0, function* () {
            const { word } = ctx.params;
            const filepath = Path.join(Config.get('datadir'), 'images', `${word}.jpg`);
            ctx.set('Content-Type', 'image/jpeg');
            ctx.body = fs.createReadStream(filepath);
        });
    }
}
tslib_1.__decorate([
    decorator_1.route('get', '/api/images/:word')
], QRCodeController.prototype, "get", null);
exports.default = QRCodeController;
//# sourceMappingURL=Image.js.map