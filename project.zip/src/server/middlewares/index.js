"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const error_1 = require("./error");
const log_1 = require("./log");
exports.default = (app) => {
    app.use(log_1.default);
    app.use(error_1.default);
};
//# sourceMappingURL=index.js.map